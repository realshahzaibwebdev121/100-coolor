/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ThemeProvider } from './components/ThemeProvider';
import { Backgrounds } from './components/Backgrounds';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Stats } from './components/Stats';
import { Features } from './components/Features';
import { Keycard } from './components/Keycard';
import { FAQ } from './components/FAQ';
import { CTA } from './components/CTA';
import { NetworkMap } from './components/Network';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <ThemeProvider>
      <Backgrounds />
      <Navbar />
      <main className="pt-32 relative z-10" id="main-content">
        <Hero />
        <Stats />
        <Features />
        <Keycard />
        <FAQ />
        <CTA />
        <NetworkMap />
        <Footer />
      </main>
    </ThemeProvider>
  );
}
