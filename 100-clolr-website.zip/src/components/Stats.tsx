import { Infinity } from 'lucide-react';
import { Reveal } from './ui/Reveal';

export function Stats() {
  return (
    <section className="bg-slate-50 dark:bg-[#0A0A0B] mt-32 relative transition-colors duration-500 border-t border-slate-200 dark:border-transparent">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[100%] h-[1px] bg-gradient-to-r from-transparent via-primary-400/50 dark:via-primary-500/50 to-transparent pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 pt-24 text-center relative z-10">
        <Reveal className="inline-flex px-3 py-1 border border-primary-300 dark:border-primary-500/20 bg-primary-100/50 dark:bg-primary-900/30 text-xs font-mono text-primary-600 dark:text-primary-500 uppercase tracking-widest mb-8 font-geist">
          Sys_Stats
        </Reveal>

        <Reveal delay={0.1}>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl tracking-widest text-slate-900 dark:text-white max-w-3xl mx-auto leading-tight mb-20 uppercase font-jakarta font-medium transition-colors">
            Global syndicate of agents committed to fortifying the neural
            architecture
          </h2>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center border-t border-b border-primary-200 dark:border-primary-500/10 py-12">
          <Reveal delay={0.2} className="text-center md:text-left">
            <p className="text-4xl tracking-tight mb-2 text-primary-500 dark:text-primary-500 font-jakarta font-medium">
              3.8+ MM
            </p>
            <p className="text-xs font-mono uppercase tracking-widest text-slate-500 dark:text-gray-300 font-geist">
              Packets Secured
            </p>
          </Reveal>

          <Reveal delay={0.3} className="flex flex-wrap justify-center gap-8 items-center opacity-70 text-slate-900 dark:text-white font-mono uppercase tracking-widest text-sm transition-colors">
            <span className="font-geist">Aegis_</span>
            <span className="flex items-center gap-1 font-geist">
              <Infinity className="w-5 h-5" />
              Cipher
            </span>
            <span className="font-geist">Vanguard</span>
          </Reveal>

          <Reveal delay={0.4} className="text-center md:text-right">
            <p className="text-4xl tracking-tight mb-2 text-primary-500 dark:text-primary-500 font-jakarta font-medium">
              75+ MM
            </p>
            <p className="text-xs font-mono uppercase tracking-widest text-slate-500 dark:text-gray-300 font-geist">
              Active Relays
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
