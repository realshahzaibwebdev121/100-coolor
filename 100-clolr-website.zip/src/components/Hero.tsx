import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <section className="min-h-[80vh] flex flex-col lg:flex-row max-w-7xl mr-auto ml-auto pr-6 pl-6 relative items-center justify-center">
      {/* Left Content */}
      <div className="lg:w-1/2 z-10 lg:pt-0 flex flex-col w-full pt-12 items-start">
        <motion.div
           initial={{ opacity: 0, y: -20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ delay: 0.8, duration: 0.8 }}
           className="flex flex-col items-start mb-6"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 border border-primary-300/50 dark:border-primary-500/20 bg-primary-100/50 dark:bg-primary-900/30 backdrop-blur-sm mb-4">
            <span className="text-xs font-mono text-slate-900 dark:text-white uppercase tracking-widest bg-primary-200 dark:bg-primary-600/50 px-2 py-0.5 border border-primary-400/50 dark:border-primary-600/80 font-geist">
              Sys_Update
            </span>
            <span className="text-xs font-mono text-primary-600 dark:text-[#FFD54F] tracking-widest uppercase font-geist">
              nexus 4.1 active
            </span>
          </div>

          <div className="flex gap-0.5 h-1 w-24 opacity-80">
            <div className="w-1 bg-primary-400 dark:bg-primary-500"></div>
            <div className="w-2 bg-primary-400 dark:bg-primary-500"></div>
            <div className="w-0.5 bg-primary-400 dark:bg-primary-500"></div>
            <div className="w-3 bg-primary-400 dark:bg-primary-500"></div>
            <div className="w-1 bg-primary-400 dark:bg-primary-500"></div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, letterSpacing: '0.5em' }}
          animate={{ opacity: 1, letterSpacing: '0.1em' }}
          transition={{ delay: 0.6, duration: 1 }}
          className="text-primary-600/80 dark:text-primary-500/80 font-mono text-xs uppercase mb-4 font-geist"
        >
          Sequence Activated
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 1.1, filter: 'blur(10px)' }}
          animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
          transition={{ delay: 1, duration: 1.5, ease: 'easeOut' }}
          className="text-5xl sm:text-6xl lg:text-[5.5rem] uppercase tracking-tight leading-[1.1] mb-6 text-metallic font-jakarta font-medium"
        >
          Made by
          <br />
          Shahzaib
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 1 }}
          className="leading-relaxed uppercase text-sm tracking-wide font-mono max-w-xl mb-10 text-slate-600 dark:text-gray-300 font-geist"
        >
          Nexus is the paramount secure tactical terminal, utilized by field
          agents to intercept, transmit, and decode encrypted data.
        </motion.p>

        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ delay: 1.4, duration: 0.8 }}
           className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto"
        >
          {/* Main Sci-Fi CTA */}
          <button className="group relative flex items-center justify-center px-8 py-3.5 w-full sm:w-auto cursor-pointer overflow-hidden bg-gray-300 dark:bg-[#1A2A3A]/40 border border-primary-200 dark:border-white/5 backdrop-blur-sm shadow-[inset_0_2px_10px_rgba(0,0,0,0.1)] dark:shadow-[inset_0_2px_10px_rgba(0,0,0,0.5)]">
            <div className="absolute left-0 top-0 bottom-0 w-[4px] bg-primary-500 dark:bg-primary-500 transition-all group-hover:w-[8px] group-hover:bg-slate-900 dark:group-hover:bg-white shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.5)] dark:shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.5)]"></div>
            <div className="absolute right-0 top-0 bottom-0 w-[4px] bg-primary-500 dark:bg-primary-500 transition-all group-hover:w-[8px] group-hover:bg-slate-900 dark:group-hover:bg-white shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.5)] dark:shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.5)]"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-primary-400/0 via-primary-400/10 to-primary-400/0 dark:from-primary-500/0 dark:via-primary-500/10 dark:to-primary-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <span className="relative z-10 text-slate-900 dark:text-white font-mono text-xs tracking-widest uppercase flex items-center gap-2 group-hover:drop-shadow-[0_0_8px_rgba(0,0,0,0.4)] dark:group-hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] transition-all font-geist">
              Engage Sequence
              <ArrowRight className="w-4 h-4" />
            </span>
          </button>

          {/* Secondary CTA */}
          <button className="w-full sm:w-auto bg-white/50 dark:bg-[#0A0A0B]/50 backdrop-blur-sm border border-slate-300 dark:border-[#9ca3af]/40 px-8 py-3.5 text-xs font-mono tracking-widest uppercase flex justify-center items-center hover:text-primary-500 dark:hover:text-primary-500 hover:border-primary-400 dark:hover:border-primary-500/40 transition-colors text-slate-600 dark:text-gray-300 font-geist">
            System Scan
          </button>
        </motion.div>
      </div>

      {/* Right Graphic (Sci-Fi Radar/Nodes) */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 1.2, duration: 2, ease: 'easeOut' }}
        className="lg:w-1/2 aspect-square max-w-[500px] lg:max-w-[700px] mx-auto lg:mt-0 flex pointer-events-none w-full mt-16 relative items-center justify-center"
      >
        <div className="absolute w-[120%] h-[120%] border border-primary-500/20 dark:border-primary-500/10 rounded-full top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute w-[90%] h-[90%] border border-primary-500/30 dark:border-primary-500/20 rounded-full top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border-dashed"></div>

        <div className="relative w-24 h-24 border-2 border-primary-500 dark:border-primary-500 rounded-full flex items-center justify-center bg-slate-50 dark:bg-[#141416]">
          <div className="absolute inset-0 bg-primary-400 dark:bg-primary-500 rounded-full blur-[30px] opacity-20"></div>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
            className="w-8 h-8 bg-primary-600 dark:bg-secondary-500 rounded-sm shadow-[0_0_15px_#6366f1]"
          ></motion.div>
        </div>

        {/* Floating Nodes */}
        <motion.div
           animate={{ y: [-10, 10, -10] }}
           transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
           className="absolute top-[20%] right-[30%] border border-primary-300 dark:border-primary-500/30 bg-white dark:bg-[#141416] p-3 shadow-[0_0_15px_rgba(var(--color-primary-500-rgb),0.2)] dark:shadow-[0_0_15px_rgba(var(--color-primary-500-rgb),0.1)]"
        >
          <div className="w-4 h-4 bg-primary-500 dark:bg-primary-600/80 rounded-sm shadow-[0_0_10px_#4f46e5]"></div>
          <div className="text-[10px] font-mono text-primary-600 dark:text-primary-500 mt-2 uppercase font-geist">
            Node_Omega
          </div>
        </motion.div>

        <motion.div
           animate={{ y: [10, -10, 10] }}
           transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
           className="absolute bottom-[30%] right-[10%] border border-primary-300 dark:border-primary-500/30 bg-white dark:bg-[#141416] p-3 shadow-[0_0_15px_rgba(var(--color-primary-500-rgb),0.2)] dark:shadow-[0_0_15px_rgba(var(--color-primary-500-rgb),0.1)]"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 text-primary-500 dark:text-primary-500">
            <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
            <polyline points="2 12 12 17 22 12"></polyline>
            <polyline points="2 17 12 22 22 17"></polyline>
          </svg>
          <div className="text-[10px] font-mono text-primary-600 dark:text-primary-500 mt-2 uppercase font-geist">
            Level_05
          </div>
        </motion.div>

        {/* Floating Data Card */}
        <motion.div
           animate={{ y: [-5, 5, -5] }}
           transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
           className="absolute bottom-[10%] right-[15%] bg-white/90 dark:bg-[#141416]/90 backdrop-blur-xl border border-primary-300 dark:border-primary-500/30 p-4 flex items-center gap-4 w-72 shadow-2xl"
        >
          <div className="w-10 h-10 bg-slate-100 dark:bg-[#0A0A0B] border border-primary-300 dark:border-primary-500/20 flex items-center justify-center">
            <div className="w-full h-[2px] bg-gradient-to-r from-primary-600 via-primary-400 to-primary-400 dark:from-primary-600 dark:via-primary-500 dark:to-primary-500 mx-2"></div>
          </div>
          <div>
            <p className="text-xs text-primary-600 dark:text-primary-500 font-mono uppercase tracking-widest font-geist">
              Vanguard Data Net
            </p>
            <p className="text-xs font-mono uppercase mt-1 text-slate-500 dark:text-gray-300 font-geist">
              Status: Active
            </p>
          </div>
        </motion.div>

      </motion.div>
    </section>
  );
}
