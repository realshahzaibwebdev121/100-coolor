import { ChevronDown, ArrowRight } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Reveal } from './ui/Reveal';
import { GlowCard } from './ui/GlowCard';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

const fAQs: FAQItem[] = [
  { id: '1', question: 'System Parameters?', answer: 'Nexus requires standard web environments. No dedicated hardware necessary for baseline intercepts. Optimal on Chromium-based viewing platforms.' },
  { id: '2', question: 'Firewall Status?', answer: 'Nexus utilizes quantum-grade shielding to guarantee complete safety of data. Access vectors are masked locally. Compromise probability: 0.0003%.' },
  { id: '3', question: 'Legacy Uplink?', answer: 'Support for pre-quantum terminal encryption standard (AES-256 equivalent) is maintained for backward compatibility.' },
  { id: '4', question: 'Data Restoration?', answer: 'In the event of localized network fragmentation, redundant satellite archives auto-sync missing packets within a 48 hour frame.' },
];

export function FAQ() {
  const [activeId, setActiveId] = useState<string>('2');
  
  const activeDetail = fAQs.find(f => f.id === activeId)?.answer || '';

  return (
    <section className="max-w-4xl mx-auto px-6 py-24" id="docs">
      <Reveal className="text-center mb-16">
        <div className="inline-flex px-3 py-1 border border-primary-300 dark:border-primary-500/20 bg-primary-100/50 dark:bg-primary-900/30 text-xs font-mono text-primary-600 dark:text-primary-500 uppercase tracking-widest mb-6 font-geist">
          Data_Logs
        </div>
        <h2 className="text-2xl sm:text-3xl uppercase tracking-widest font-jakarta font-medium">
          Network Logs
        </h2>

        <div className="flex justify-center gap-8 mt-10 border-b border-primary-200 dark:border-primary-500/10">
          <button className="pb-4 text-xs font-mono uppercase tracking-widest text-primary-600 dark:text-primary-500 border-b-2 border-primary-500 dark:border-primary-500 font-geist">
            Core
          </button>
          <button className="pb-4 text-xs font-mono uppercase tracking-widest hover:text-primary-500 dark:hover:text-primary-500 text-slate-500 dark:text-gray-300 transition-colors font-geist">
            Network
          </button>
          <button className="pb-4 text-xs font-mono uppercase tracking-widest hover:text-primary-500 dark:hover:text-primary-500 text-slate-500 dark:text-gray-300 transition-colors font-geist">
            Hardware
          </button>
        </div>
      </Reveal>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        <Reveal delay={0.2} className="flex flex-col">
          {fAQs.map((faq) => {
            const isActive = activeId === faq.id;
            return (
              <button
                key={faq.id}
                onClick={() => setActiveId(isActive ? '' : faq.id)}
                className={`flex items-center justify-between py-5 border-b font-mono uppercase tracking-widest transition-all font-geist text-left
                  ${isActive 
                    ? 'px-4 my-2 bg-slate-50 dark:bg-[#141416] border-primary-400 dark:border-primary-500 shadow-[inset_0_0_10px_rgba(var(--color-primary-500-rgb),0.1)] dark:shadow-[inset_0_0_10px_rgba(var(--color-primary-500-rgb),0.2)] text-primary-600 dark:text-primary-500' 
                    : 'border-primary-200 dark:border-primary-500/10 hover:text-primary-500 dark:hover:text-primary-500 text-slate-600 dark:text-gray-300'
                  }
                  text-xs
                `}
              >
                {faq.question}
                {isActive ? <ArrowRight className="w-4 h-4 shrink-0" /> : <ChevronDown className="w-4 h-4 shrink-0" />}
              </button>
            );
          })}
        </Reveal>

        <Reveal delay={0.3} className="h-full min-h-[250px]">
          <GlowCard className="p-8 h-full bg-white dark:bg-[#0A0A0B] shadow-lg dark:shadow-[inset_0_0_20px_rgba(var(--color-primary-500-rgb),0.05)] border border-slate-200 dark:border-primary-500/20 transition-colors">
            <div className="relative z-10 h-full">
              <AnimatePresence mode="wait">
                <motion.p
                  key={activeId}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="text-xs font-mono uppercase tracking-wider leading-loose text-slate-700 dark:text-gray-300 font-geist"
                >
                  &gt;&gt; Analyzing security vector...
                  <br /><br />
                  {activeDetail || 'Awaiting query selection...'}
                </motion.p>
              </AnimatePresence>
            </div>
          </GlowCard>
        </Reveal>
      </div>
    </section>
  );
}
