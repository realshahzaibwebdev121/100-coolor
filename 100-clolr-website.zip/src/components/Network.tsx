import { Server, Cpu, Network, ShieldCheck } from 'lucide-react';
import { GlowCard } from './ui/GlowCard';
import { Reveal } from './ui/Reveal';

const nodes = [
  {
    id: 1,
    icon: Server,
    title: 'Tokyo_Relay',
    description: 'Primary Asian-Pacific junction. Handling 42% of cross-grid packet routing and intercept distribution.',
    integrity: '99.9%'
  },
  {
    id: 2,
    icon: Cpu,
    title: 'Frankfurt_Node',
    description: 'Central European logic processor. Executes quantum decryption and continuous cryptographic key rotation.',
    integrity: '98.4%'
  },
  {
    id: 3,
    icon: Network,
    title: 'NA_East_Cluster',
    description: 'High-bandwidth data aggregation. Maintains direct multi-channel uplink to orbital defense grid relays.',
    integrity: '99.1%'
  }
];

export function NetworkMap() {
  return (
    <section className="py-24 relative overflow-hidden border-t border-primary-200 dark:border-primary-500/10 bg-slate-50 dark:bg-[#0A0A0B] transition-colors duration-500" id="platform">
      <div className="absolute inset-0 pointer-events-none opacity-[0.02]" style={{ backgroundImage: "repeating-linear-gradient(-45deg, transparent, transparent 10px, currentColor 10px, currentColor 11px)" }}></div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Header */}
        <Reveal className="flex flex-col items-center text-center mb-20">
          <div className="inline-flex px-3 py-1 border border-primary-300 dark:border-primary-500/20 bg-primary-100/50 dark:bg-primary-900/30 text-xs font-mono text-primary-600 dark:text-primary-500 uppercase tracking-widest mb-6 font-geist shadow-sm dark:shadow-[inset_0_0_8px_rgba(var(--color-primary-500-rgb),0.2)]">
            Network_Topology
          </div>
          <h2 className="text-3xl md:text-5xl uppercase tracking-tight font-jakarta font-medium mb-6">
            Synchronized Terminals
          </h2>
          <p className="text-xs font-mono uppercase tracking-widest text-slate-500 dark:text-gray-300 max-w-2xl font-geist leading-relaxed opacity-80">
            Global relays maintaining quantum-level encryption and real-time synchronization across the mainframe architecture.
          </p>
        </Reveal>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {nodes.map((node, index) => (
            <div key={node.id} className="h-full">
              <Reveal delay={0.2 + (index * 0.1)} className="h-full">
                <GlowCard className="p-8 h-full bg-white/90 dark:bg-[#141416]/90 backdrop-blur-md border border-slate-300 dark:border-primary-500/20 hover:border-primary-400 dark:hover:border-primary-500/60 transition-all duration-500 group overflow-hidden shadow-lg dark:shadow-[0_0_20px_rgba(0,0,0,0.8),inset_0_0_20px_rgba(var(--color-primary-500-rgb),0.05)]">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary-400/5 dark:bg-secondary-500/5 blur-[40px] group-hover:bg-primary-400/20 dark:group-hover:bg-secondary-500/20 transition-colors duration-500"></div>
                
                {/* Corner Accents */}
                <div className="absolute top-0 left-0 w-4 h-4 border-t border-l border-primary-400/50 dark:border-primary-500/50 transition-all duration-300 group-hover:w-6 group-hover:h-6 group-hover:border-primary-500 dark:group-hover:border-primary-500"></div>
                <div className="absolute top-0 right-0 w-4 h-4 border-t border-r border-primary-400/50 dark:border-primary-500/50 transition-all duration-300 group-hover:w-6 group-hover:h-6 group-hover:border-primary-500 dark:group-hover:border-primary-500"></div>
                <div className="absolute bottom-0 left-0 w-4 h-4 border-b border-l border-primary-400/50 dark:border-primary-500/50 transition-all duration-300 group-hover:w-6 group-hover:h-6 group-hover:border-primary-500 dark:group-hover:border-primary-500"></div>
                <div className="absolute bottom-0 right-0 w-4 h-4 border-b border-r border-primary-400/50 dark:border-primary-500/50 transition-all duration-300 group-hover:w-6 group-hover:h-6 group-hover:border-primary-500 dark:group-hover:border-primary-500"></div>

                <div className="relative z-10 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-16">
                    <div className="w-12 h-12 border border-primary-300 dark:border-primary-500/30 flex items-center justify-center bg-slate-50 dark:bg-[#0A0A0B] text-primary-500 dark:text-primary-500 group-hover:scale-110 group-hover:border-primary-500 dark:group-hover:border-primary-500 transition-all duration-300 shadow-sm dark:shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.1)]">
                      <node.icon className="w-6 h-6" />
                    </div>
                    <div className="flex items-center gap-2 bg-slate-50 dark:bg-[#0A0A0B] border border-primary-200 dark:border-primary-500/20 px-2 py-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary-500 dark:bg-primary-500 shadow-[0_0_5px_currentColor] animate-[pulse_2s_ease-in-out_infinite]"></div>
                      <span className="text-[10px] font-mono text-primary-600 dark:text-primary-500 uppercase tracking-widest font-geist">Active</span>
                    </div>
                  </div>
                  
                  <h3 className="text-2xl tracking-tight uppercase font-jakarta font-medium mb-3">
                    {node.title}
                  </h3>
                  <p className="text-xs font-mono uppercase text-slate-500 dark:text-gray-300 mb-10 font-geist leading-relaxed opacity-80">
                    {node.description}
                  </p>
                  
                  <div className="mt-auto space-y-3 border-t border-primary-200 dark:border-primary-500/10 pt-6">
                    <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-widest text-slate-600 dark:text-gray-300 font-geist">
                      <span>Integrity_Level</span>
                      <span className="text-primary-600 dark:text-primary-500">{node.integrity}</span>
                    </div>
                    <div className="w-full h-1 bg-slate-200 dark:bg-[#0A0A0B] border border-primary-200 dark:border-primary-500/20 overflow-hidden relative">
                      <div className="absolute top-0 left-0 h-full bg-primary-400 dark:bg-primary-500 shadow-[0_0_8px_currentColor]" style={{ width: node.integrity }}></div>
                    </div>
                  </div>
                </div>
              </GlowCard>
              </Reveal>
            </div>
          ))}
        </div>
        
        {/* Bottom Status */}
        <Reveal delay={0.6} className="mt-16 flex justify-center relative z-10">
          <div className="inline-flex items-center gap-4 border border-primary-300 dark:border-primary-500/30 bg-white/60 dark:bg-[#141416]/60 px-6 py-3 backdrop-blur-sm shadow-sm dark:shadow-[inset_0_0_10px_rgba(var(--color-primary-500-rgb),0.1)]">
            <ShieldCheck className="w-5 h-5 text-primary-500 dark:text-primary-500" />
            <span className="text-xs font-mono uppercase tracking-widest font-geist text-slate-900 dark:text-white">
              All sectors reporting nominal status
            </span>
            <div className="flex gap-1 ml-4 text-primary-500 dark:text-primary-500">
              <div className="w-1 h-3 bg-current opacity-100"></div>
              <div className="w-1 h-3 bg-current opacity-80"></div>
              <div className="w-1 h-3 bg-current opacity-60"></div>
              <div className="w-1 h-3 bg-current opacity-40"></div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
