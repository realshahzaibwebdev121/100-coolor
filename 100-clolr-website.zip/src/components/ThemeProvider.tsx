import React from 'react';
import { createContext, useContext, useEffect, useState } from 'react';

type Theme = 'dark' | 'light';
export type AccentColor = 'indigo' | 'red' | 'orange' | 'emerald' | 'teal' | 'cyan' | 'blue' | 'violet' | 'fuchsia' | 'pink' | 'rose' | 'yellow' | 'lime' | 'amber' | 'sky' | 'crimson' | 'ruby' | 'tomato' | 'coral' | 'salmon' | 'sienna' | 'rust' | 'bronze' | 'gold' | 'olive' | 'chartreuse' | 'forest' | 'pine' | 'mint' | 'aegean' | 'ocean' | 'azure' | 'navy' | 'cobalt' | 'sapphire' | 'lapis' | 'plum' | 'orchid' | 'magenta' | 'berry' | 'grape' | 'lilac' | 'lavender' | 'mauve' | 'slate' | 'zinc' | 'charcoal' | 'steel' | 'silver' | 'sand' | 'c-h0-s90' | 'c-h14-s90' | 'c-h29-s90' | 'c-h43-s90' | 'c-h58-s90' | 'c-h72-s90' | 'c-h86-s90' | 'c-h101-s90' | 'c-h115-s90' | 'c-h130-s90' | 'c-h144-s90' | 'c-h158-s90' | 'c-h173-s90' | 'c-h187-s90' | 'c-h202-s90' | 'c-h216-s90' | 'c-h230-s90' | 'c-h245-s90' | 'c-h259-s90' | 'c-h274-s90' | 'c-h288-s90' | 'c-h302-s90' | 'c-h317-s90' | 'c-h331-s90' | 'c-h346-s90' | 'c-h0-s70' | 'c-h14-s70' | 'c-h29-s70' | 'c-h43-s70' | 'c-h58-s70' | 'c-h72-s70' | 'c-h86-s70' | 'c-h101-s70' | 'c-h115-s70' | 'c-h130-s70' | 'c-h144-s70' | 'c-h158-s70' | 'c-h173-s70' | 'c-h187-s70' | 'c-h202-s70' | 'c-h216-s70' | 'c-h230-s70' | 'c-h245-s70' | 'c-h259-s70' | 'c-h274-s70' | 'c-h288-s70' | 'c-h302-s70' | 'c-h317-s70' | 'c-h331-s70' | 'c-h346-s70' | 'c-h0-s50' | 'c-h14-s50' | 'c-h29-s50' | 'c-h43-s50' | 'c-h58-s50' | 'c-h72-s50' | 'c-h86-s50' | 'c-h101-s50' | 'c-h115-s50' | 'c-h130-s50' | 'c-h144-s50' | 'c-h158-s50' | 'c-h173-s50' | 'c-h187-s50' | 'c-h202-s50' | 'c-h216-s50' | 'c-h230-s50' | 'c-h245-s50' | 'c-h259-s50' | 'c-h274-s50' | 'c-h288-s50' | 'c-h302-s50' | 'c-h317-s50' | 'c-h331-s50' | 'c-h346-s50' | 'c-h0-s30' | 'c-h14-s30' | 'c-h29-s30' | 'c-h43-s30' | 'c-h58-s30' | 'c-h72-s30' | 'c-h86-s30' | 'c-h101-s30' | 'c-h115-s30' | 'c-h130-s30' | 'c-h144-s30' | 'c-h158-s30' | 'c-h173-s30' | 'c-h187-s30' | 'c-h202-s30' | 'c-h216-s30' | 'c-h230-s30' | 'c-h245-s30' | 'c-h259-s30' | 'c-h274-s30' | 'c-h288-s30' | 'c-h302-s30' | 'c-h317-s30' | 'c-h331-s30' | 'c-h346-s30';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
  accent: AccentColor;
  setAccent: (color: AccentColor) => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'dark',
  toggleTheme: () => {},
  accent: 'indigo',
  setAccent: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('dark');
  const [accent, setAccent] = useState<AccentColor>('indigo');

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
  }, [theme]);

  useEffect(() => {
    const root = window.document.documentElement;
    if (accent === 'indigo') {
      root.removeAttribute('data-accent');
    } else {
      root.setAttribute('data-accent', accent);
    }
  }, [accent]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, accent, setAccent }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);

