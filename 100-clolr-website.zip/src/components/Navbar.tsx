import { Menu, Moon, Sparkles, Sun, X, Palette } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { useTheme, AccentColor } from './ThemeProvider';
import { motion, AnimatePresence } from 'motion/react';

const COLORS: { name: AccentColor, hex: string }[] = [
  { name: 'rose', hex: '#f43f5e' },
  { name: 'pink', hex: '#ec4899' },
  { name: 'fuchsia', hex: '#d946ef' },
  { name: 'violet', hex: '#8b5cf6' },
  { name: 'indigo', hex: '#6366f1' },
  { name: 'blue', hex: '#3b82f6' },
  { name: 'sky', hex: '#0ea5e9' },
  { name: 'cyan', hex: '#06b6d4' },
  { name: 'teal', hex: '#14b8a6' },
  { name: 'emerald', hex: '#10b981' },
  { name: 'lime', hex: '#84cc16' },
  { name: 'yellow', hex: '#eab308' },
  { name: 'amber', hex: '#f59e0b' },
  { name: 'orange', hex: '#f97316' },
  { name: 'red', hex: '#ef4444' },
  { name: 'crimson', hex: '#dc143c' },
  { name: 'ruby', hex: '#e0115f' },
  { name: 'tomato', hex: '#ff6347' },
  { name: 'coral', hex: '#ff7f50' },
  { name: 'salmon', hex: '#fa8072' },
  { name: 'sienna', hex: '#a0522d' },
  { name: 'rust', hex: '#b7410e' },
  { name: 'bronze', hex: '#cd7f32' },
  { name: 'gold', hex: '#ffd700' },
  { name: 'olive', hex: '#808000' },
  { name: 'chartreuse', hex: '#7fff00' },
  { name: 'forest', hex: '#228b22' },
  { name: 'pine', hex: '#01796f' },
  { name: 'mint', hex: '#98ff98' },
  { name: 'aegean', hex: '#1f456e' },
  { name: 'ocean', hex: '#0077be' },
  { name: 'azure', hex: '#007fff' },
  { name: 'navy', hex: '#000080' },
  { name: 'cobalt', hex: '#0047ab' },
  { name: 'sapphire', hex: '#0f52ba' },
  { name: 'lapis', hex: '#26619c' },
  { name: 'plum', hex: '#dda0dd' },
  { name: 'orchid', hex: '#da70d6' },
  { name: 'magenta', hex: '#ff00ff' },
  { name: 'berry', hex: '#8a2be2' },
  { name: 'grape', hex: '#6f2da8' },
  { name: 'lilac', hex: '#c8a2c8' },
  { name: 'lavender', hex: '#e6e6fa' },
  { name: 'mauve', hex: '#e0b0ff' },
  { name: 'slate', hex: '#708090' },
  { name: 'zinc', hex: '#a4b2c6' },
  { name: 'charcoal', hex: '#36454f' },
  { name: 'steel', hex: '#4682b4' },
  { name: 'silver', hex: '#c0c0c0' },
  { name: 'sand', hex: '#c2b280' },
  { name: 'c-h0-s90', hex: '#f20d0d' },
  { name: 'c-h14-s90', hex: '#f2420d' },
  { name: 'c-h29-s90', hex: '#f27c0d' },
  { name: 'c-h43-s90', hex: '#f2b10d' },
  { name: 'c-h58-s90', hex: '#f2eb0d' },
  { name: 'c-h72-s90', hex: '#c4f20d' },
  { name: 'c-h86-s90', hex: '#8ff20d' },
  { name: 'c-h101-s90', hex: '#55f20d' },
  { name: 'c-h115-s90', hex: '#20f20d' },
  { name: 'c-h130-s90', hex: '#0df233' },
  { name: 'c-h144-s90', hex: '#0df269' },
  { name: 'c-h158-s90', hex: '#0df29e' },
  { name: 'c-h173-s90', hex: '#0df2d7' },
  { name: 'c-h187-s90', hex: '#0dd7f2' },
  { name: 'c-h202-s90', hex: '#0d9ef2' },
  { name: 'c-h216-s90', hex: '#0d69f2' },
  { name: 'c-h230-s90', hex: '#0d33f2' },
  { name: 'c-h245-s90', hex: '#200df2' },
  { name: 'c-h259-s90', hex: '#550df2' },
  { name: 'c-h274-s90', hex: '#8f0df2' },
  { name: 'c-h288-s90', hex: '#c40df2' },
  { name: 'c-h302-s90', hex: '#f20deb' },
  { name: 'c-h317-s90', hex: '#f20db1' },
  { name: 'c-h331-s90', hex: '#f20d7c' },
  { name: 'c-h346-s90', hex: '#f20d42' },
  { name: 'c-h0-s70', hex: '#d92626' },
  { name: 'c-h14-s70', hex: '#d95026' },
  { name: 'c-h29-s70', hex: '#d97d26' },
  { name: 'c-h43-s70', hex: '#d9a626' },
  { name: 'c-h58-s70', hex: '#d9d326' },
  { name: 'c-h72-s70', hex: '#b5d926' },
  { name: 'c-h86-s70', hex: '#8bd926' },
  { name: 'c-h101-s70', hex: '#5fd926' },
  { name: 'c-h115-s70', hex: '#35d926' },
  { name: 'c-h130-s70', hex: '#26d944' },
  { name: 'c-h144-s70', hex: '#26d96e' },
  { name: 'c-h158-s70', hex: '#26d997' },
  { name: 'c-h173-s70', hex: '#26d9c4' },
  { name: 'c-h187-s70', hex: '#26c4d9' },
  { name: 'c-h202-s70', hex: '#2697d9' },
  { name: 'c-h216-s70', hex: '#266ed9' },
  { name: 'c-h230-s70', hex: '#2644d9' },
  { name: 'c-h245-s70', hex: '#3526d9' },
  { name: 'c-h259-s70', hex: '#5f26d9' },
  { name: 'c-h274-s70', hex: '#8b26d9' },
  { name: 'c-h288-s70', hex: '#b526d9' },
  { name: 'c-h302-s70', hex: '#d926d3' },
  { name: 'c-h317-s70', hex: '#d926a6' },
  { name: 'c-h331-s70', hex: '#d9267d' },
  { name: 'c-h346-s70', hex: '#d92650' },
  { name: 'c-h0-s50', hex: '#bf4040' },
  { name: 'c-h14-s50', hex: '#bf5e40' },
  { name: 'c-h29-s50', hex: '#bf7d40' },
  { name: 'c-h43-s50', hex: '#bf9b40' },
  { name: 'c-h58-s50', hex: '#bfbb40' },
  { name: 'c-h72-s50', hex: '#a6bf40' },
  { name: 'c-h86-s50', hex: '#88bf40' },
  { name: 'c-h101-s50', hex: '#68bf40' },
  { name: 'c-h115-s50', hex: '#4abf40' },
  { name: 'c-h130-s50', hex: '#40bf55' },
  { name: 'c-h144-s50', hex: '#40bf73' },
  { name: 'c-h158-s50', hex: '#40bf91' },
  { name: 'c-h173-s50', hex: '#40bfb0' },
  { name: 'c-h187-s50', hex: '#40b0bf' },
  { name: 'c-h202-s50', hex: '#4090bf' },
  { name: 'c-h216-s50', hex: '#4073bf' },
  { name: 'c-h230-s50', hex: '#4055bf' },
  { name: 'c-h245-s50', hex: '#4a40bf' },
  { name: 'c-h259-s50', hex: '#6840bf' },
  { name: 'c-h274-s50', hex: '#8840bf' },
  { name: 'c-h288-s50', hex: '#a640bf' },
  { name: 'c-h302-s50', hex: '#bf40bb' },
  { name: 'c-h317-s50', hex: '#bf409b' },
  { name: 'c-h331-s50', hex: '#bf407d' },
  { name: 'c-h346-s50', hex: '#bf405d' },
  { name: 'c-h0-s30', hex: '#a65959' },
  { name: 'c-h14-s30', hex: '#a66b59' },
  { name: 'c-h29-s30', hex: '#a67e59' },
  { name: 'c-h43-s30', hex: '#a69059' },
  { name: 'c-h58-s30', hex: '#a6a359' },
  { name: 'c-h72-s30', hex: '#96a659' },
  { name: 'c-h86-s30', hex: '#85a659' },
  { name: 'c-h101-s30', hex: '#71a659' },
  { name: 'c-h115-s30', hex: '#60a659' },
  { name: 'c-h130-s30', hex: '#59a666' },
  { name: 'c-h144-s30', hex: '#59a678' },
  { name: 'c-h158-s30', hex: '#59a68a' },
  { name: 'c-h173-s30', hex: '#59a69d' },
  { name: 'c-h187-s30', hex: '#599da6' },
  { name: 'c-h202-s30', hex: '#598aa6' },
  { name: 'c-h216-s30', hex: '#5978a6' },
  { name: 'c-h230-s30', hex: '#5966a6' },
  { name: 'c-h245-s30', hex: '#6059a6' },
  { name: 'c-h259-s30', hex: '#7159a6' },
  { name: 'c-h274-s30', hex: '#8559a6' },
  { name: 'c-h288-s30', hex: '#9659a6' },
  { name: 'c-h302-s30', hex: '#a659a3' },
  { name: 'c-h317-s30', hex: '#a65990' },
  { name: 'c-h331-s30', hex: '#a6597e' },
  { name: 'c-h346-s30', hex: '#a6596b' },
];

export function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isColorMenuOpen, setIsColorMenuOpen] = useState(false);
  const { theme, toggleTheme, accent, setAccent } = useTheme();
  
  const colorMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (colorMenuRef.current && !colorMenuRef.current.contains(event.target as Node)) {
        setIsColorMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav className="fixed top-0 left-0 right-0 z-[40] bg-white/80 dark:bg-[#0A0A0B]/80 backdrop-blur-md border-b border-primary-200 dark:border-primary-500/10 transition-colors duration-500">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        {/* Logo */}
        <div className="flex-1 flex items-center gap-3 group cursor-pointer">
          <div className="w-6 h-6 border border-primary-500 dark:border-primary-500 flex items-center justify-center relative overflow-hidden bg-primary-100 dark:bg-primary-900/50 transition-colors duration-500">
            <div className="w-1.5 h-1.5 bg-primary-500 dark:bg-primary-400 relative z-10 shadow-[0_0_8px_var(--color-primary-500)]"></div>
          </div>
          <span className="uppercase text-xl font-medium tracking-widest font-jakarta transition-colors group-hover:text-primary-500">nexus</span>
        </div>

        {/* Links (Desktop) */}
        <div className="hidden md:flex items-center gap-10 text-xs font-mono tracking-widest uppercase text-slate-600 dark:text-gray-300">
          <a href="#features" className="hover:text-primary-500 dark:hover:text-primary-400 transition-colors font-geist">Features</a>
          <a href="#developer" className="hover:text-primary-500 dark:hover:text-primary-400 transition-colors font-geist">Developer</a>
          <a href="#platform" className="hover:text-primary-500 dark:hover:text-primary-400 transition-colors font-geist">Platform</a>
          <a href="#docs" className="hover:text-primary-500 dark:hover:text-primary-400 transition-colors flex items-center gap-1 font-geist">
            Docs
            <span className="text-primary-500 dark:text-primary-400 mb-1 font-geist border-b border-primary-500/30">v3.4</span>
          </a>
        </div>

        {/* Actions */}
        <div className="flex-1 flex items-center justify-end gap-2">
          <div className="relative" ref={colorMenuRef}>
            <button onClick={() => setIsColorMenuOpen(!isColorMenuOpen)} className="p-2 text-slate-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-500 transition-colors" aria-label="Choose Theme Color">
              <Palette className="w-4 h-4" />
            </button>
            <AnimatePresence>
              {isColorMenuOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 top-full mt-2 p-3 bg-white dark:bg-[#141416] border border-primary-200 dark:border-primary-500/20 shadow-xl w-[80vw] max-w-[800px] z-[60] grid grid-cols-8 sm:grid-cols-12 md:grid-cols-16 max-h-[60vh] overflow-y-auto gap-2"
                >
                  {COLORS.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => {
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        setAccent(c.name as any);
                        setIsColorMenuOpen(false);
                      }}
                      className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-transform hover:scale-110 ${accent === c.name ? 'border-primary-500 dark:border-white scale-110' : 'border-transparent'}`}
                      style={{ backgroundColor: c.hex }}
                      aria-label={`Select ${c.name} color`}
                    />
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button onClick={toggleTheme} className="p-2 text-slate-600 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-500 transition-colors" aria-label="Toggle Theme">
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          
          <a href="#auth" className="text-xs font-mono uppercase tracking-widest hover:text-primary-500 dark:hover:text-primary-500 hidden sm:block text-slate-600 dark:text-gray-300 font-geist ml-2">
            Auth_Req
          </a>

          {/* Sci-Fi Button (MD Style) */}
          <button className="hidden sm:flex group relative items-center justify-center px-6 py-2.5 cursor-pointer overflow-hidden bg-primary-500/10 dark:bg-primary-500/10 border border-primary-500/30 backdrop-blur-sm shadow-[inset_0_2px_10px_var(--color-primary-500)] dark:shadow-[inset_0_2px_10px_var(--color-primary-500)]">
            <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-primary-400 dark:bg-primary-500 transition-all group-hover:w-[6px] shadow-[0_0_10px_var(--color-primary-500)]"></div>
            <div className="absolute right-0 top-0 bottom-0 w-[3px] bg-primary-400 dark:bg-primary-500 transition-all group-hover:w-[6px] shadow-[0_0_10px_var(--color-primary-500)]"></div>
            <div className="absolute inset-0 bg-primary-500/40 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <span className="relative z-10 font-mono text-xs tracking-widest uppercase flex items-center gap-2 group-hover:drop-shadow-[0_0_8px_var(--color-primary-500)] transition-all font-geist text-slate-800 dark:text-gray-200 group-hover:text-white">
              Initialize
              <Sparkles className="w-4 h-4 opacity-70 group-hover:text-white" />
            </span>
          </button>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden p-2 text-slate-600 dark:text-gray-300" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden border-t border-primary-200 dark:border-primary-500/10 overflow-hidden bg-white/95 dark:bg-[#141416]/95 backdrop-blur-lg"
          >
            <div className="flex flex-col py-6 px-6 gap-6 font-mono text-sm tracking-widest uppercase text-slate-700 dark:text-gray-300">
              <a href="#features" onClick={() => setIsMobileMenuOpen(false)} className="hover:text-primary-500 dark:hover:text-primary-500 transition-colors">Features</a>
              <a href="#developer" onClick={() => setIsMobileMenuOpen(false)} className="hover:text-primary-500 dark:hover:text-primary-500 transition-colors">Developer</a>
              <a href="#platform" onClick={() => setIsMobileMenuOpen(false)} className="hover:text-primary-500 dark:hover:text-primary-500 transition-colors">Platform</a>
              <a href="#docs" onClick={() => setIsMobileMenuOpen(false)} className="hover:text-primary-500 dark:hover:text-primary-500 transition-colors">Docs [34]</a>
              <div className="h-px bg-primary-200 dark:bg-primary-500/20 my-2 w-full"></div>
              <button className="flex items-center justify-center gap-2 p-3 bg-primary-100 dark:bg-[#1A2A3A] border border-primary-300 dark:border-primary-500/30 text-slate-900 dark:text-white">
                Initialize <Sparkles className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
