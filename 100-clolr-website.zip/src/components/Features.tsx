import { ArrowRight, ArrowUpDown, Banknote, Box, Globe } from 'lucide-react';
import { GlowCard } from './ui/GlowCard';
import { Reveal } from './ui/Reveal';

export function Features() {
  return (
    <section className="max-w-7xl mx-auto px-6 py-32" id="features">
      <Reveal className="mb-12 border-l-[6px] border-primary-500 dark:border-primary-500 pl-6 shadow-[inset_2px_0_10px_rgba(var(--color-primary-500-rgb),0.05)] dark:shadow-[inset_2px_0_10px_rgba(var(--color-primary-500-rgb),0.1)]">
        <div className="text-xs font-mono text-primary-600 dark:text-primary-500 uppercase tracking-widest mb-4 font-geist">
          System_Specs
        </div>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <h2 className="text-3xl sm:text-4xl tracking-widest max-w-md leading-tight uppercase font-jakarta font-medium">
            Encrypted Data Transfers
          </h2>
          <p className="text-xs font-mono uppercase tracking-widest max-w-sm md:text-right text-slate-500 dark:text-gray-300 font-geist">
            Verified local hubs. Intercept via DarkNet and Web4.
          </p>
        </div>
      </Reveal>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Card 1 */}
        <Reveal delay={0.1} className="md:col-span-12 lg:col-span-5 h-full">
          <GlowCard className="p-8 h-full bg-white dark:bg-[#0A0A0B] shadow-lg dark:shadow-[0_0_30px_rgba(0,0,0,0.8),inset_0_0_20px_rgba(var(--color-primary-500-rgb),0.05)] border border-slate-200 dark:border-primary-500/20 group overflow-hidden transition-colors">
            <div className="absolute inset-0 pointer-events-none opacity-[0.03] dark:opacity-[0.03]" style={{ backgroundImage: "repeating-linear-gradient(-45deg, transparent, transparent 10px, currentColor 10px, currentColor 11px)" }}></div>
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/5 dark:bg-secondary-500/5 blur-[80px] group-hover:bg-primary-500/10 dark:group-hover:bg-secondary-500/10 transition-colors"></div>

            <div className="relative z-10 flex flex-col h-full">
              <h3 className="text-xl tracking-widest mb-2 uppercase font-jakarta font-medium">
                Bypass Protocol
              </h3>
              <p className="text-xs font-mono uppercase mb-12 max-w-xs leading-relaxed text-slate-500 dark:text-gray-300 font-geist">
                Analog to digital conversion executed locally from terminal.
              </p>

              {/* Mock UI */}
              <div className="w-full max-w-[280px] mx-auto relative border border-primary-300 dark:border-primary-500/20 p-4 bg-slate-50 dark:bg-[#0A0A0B] my-auto">
                <div className="flex flex-col items-center gap-2 relative z-10">
                  <div className="bg-white dark:bg-[#141416] border border-primary-200 dark:border-primary-500/20 p-4 w-full flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 border border-primary-300 dark:border-primary-500/30 flex items-center justify-center">
                        <Box className="w-4 h-4 text-primary-500 dark:text-primary-500" />
                      </div>
                      <span className="font-mono font-medium text-sm font-geist">SOL</span>
                    </div>
                    <span className="font-mono text-slate-500 dark:text-gray-300 font-geist">0.0</span>
                  </div>

                  <div className="w-10 h-10 border border-primary-500 dark:border-primary-500 bg-slate-50 dark:bg-[#0A0A0B] flex items-center justify-center -my-4 relative z-10 shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.1)] dark:shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.2)]">
                    <ArrowUpDown className="w-5 h-5 text-primary-500 dark:text-primary-500" />
                  </div>

                  <div className="bg-white dark:bg-[#141416] border border-primary-200 dark:border-primary-500/20 p-4 w-full flex items-center justify-between opacity-70 dark:opacity-50">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 border border-primary-400 dark:border-secondary-500/50 flex items-center justify-center">
                        <Banknote className="w-4 h-4 text-primary-500 dark:text-secondary-500" />
                      </div>
                      <span className="font-mono font-medium text-sm font-geist">USDC</span>
                    </div>
                    <span className="font-mono text-slate-500 dark:text-gray-300 font-geist">0.0</span>
                  </div>
                </div>
              </div>

              <div className="mt-12">
                <button className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-primary-600 dark:text-primary-500 hover:text-primary-800 dark:hover:text-white transition-colors font-geist">
                  Execute_Write <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </GlowCard>
        </Reveal>

        {/* Card 2 */}
        <Reveal delay={0.2} className="md:col-span-12 lg:col-span-7 h-full">
          <GlowCard className="p-8 h-full bg-white dark:bg-[#0A0A0B] shadow-lg dark:shadow-[0_0_30px_rgba(0,0,0,0.8),inset_0_0_20px_rgba(var(--color-primary-500-rgb),0.05)] border border-slate-200 dark:border-primary-500/20 group overflow-hidden transition-colors">
            <div className="absolute inset-0 pointer-events-none opacity-[0.03] dark:opacity-[0.03]" style={{ backgroundImage: "repeating-linear-gradient(-45deg, transparent, transparent 10px, currentColor 10px, currentColor 11px)" }}></div>
            <div className="absolute top-1/2 right-1/4 w-64 h-64 bg-primary-500/5 dark:bg-secondary-500/5 blur-[80px] group-hover:bg-primary-500/10 dark:group-hover:bg-secondary-500/10 transition-colors"></div>
            <div className="relative z-10 h-full flex flex-col">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h3 className="text-xl tracking-widest mb-2 uppercase font-jakarta font-medium">
                    Live Network Feed
                  </h3>
                  <p className="text-xs font-mono uppercase max-w-sm text-slate-500 dark:text-gray-300 font-geist">
                    Ping relays for minimal latency.
                  </p>
                </div>
              </div>

              {/* Mock Chart Area */}
              <div className="flex-1 relative mt-auto pt-10 border-b border-primary-200 dark:border-primary-500/10 pb-4 min-h-[200px]">
                <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 100">
                  <path d="M0,80 Q20,60 40,70 T80,30 T100,10" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-primary-500 dark:text-primary-500 drop-shadow-[0_0_5px_rgba(var(--color-primary-500-rgb),0.3)] dark:drop-shadow-[0_0_5px_rgba(var(--color-primary-500-rgb),0.5)]"></path>
                  <path d="M0,80 Q20,60 40,70 T80,30 T100,10 L100,100 L0,100 Z" fill="url(#grad)" opacity="0.1" className="dark:opacity-[0.15]"></path>
                  <defs>
                    <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6366f1" className="dark:stop-color-primary-500"></stop>
                      <stop offset="100%" stopColor="transparent"></stop>
                    </linearGradient>
                  </defs>
                </svg>

                <div className="absolute top-[20%] left-[60%] flex flex-col items-center">
                  <div className="bg-primary-500 dark:bg-primary-500 w-1.5 h-1.5 rounded-sm shadow-[0_0_5px_#6366f1] dark:shadow-[0_0_5px_#6366f1] mb-2"></div>
                  <div className="bg-white dark:bg-[#0A0A0B] border border-primary-300 dark:border-primary-500/30 p-2 text-center min-w-[120px] shadow-sm">
                    <p className="text-xs font-mono uppercase mb-1 font-geist">Synapse</p>
                    <p className="text-xs font-mono text-primary-600 dark:text-primary-500 font-geist">$480.5 USDC</p>
                  </div>
                </div>
              </div>
            </div>
          </GlowCard>
        </Reveal>

        {/* Card 3 */}
        <Reveal delay={0.3} className="md:col-span-12 lg:col-span-7 h-full">
          <GlowCard className="p-8 h-full min-h-[350px] bg-white dark:bg-[#0A0A0B] shadow-lg dark:shadow-[0_0_30px_rgba(0,0,0,0.8),inset_0_0_20px_rgba(var(--color-primary-500-rgb),0.05)] border border-slate-200 dark:border-primary-500/20 transition-colors overflow-hidden">
            <div className="absolute inset-0 pointer-events-none opacity-[0.03] dark:opacity-[0.03]" style={{ backgroundImage: "repeating-linear-gradient(-45deg, transparent, transparent 10px, currentColor 10px, currentColor 11px)" }}></div>
            <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-primary-500/10 dark:bg-secondary-500/10 blur-[60px] rounded-full"></div>

            <div className="relative z-10 flex flex-col h-full justify-between">
              <div className="w-16 h-16 border-2 border-primary-400 dark:border-primary-500 flex items-center justify-center bg-slate-50 dark:bg-[#0A0A0B] shadow-[0_0_15px_rgba(var(--color-primary-500-rgb),0.1)] dark:shadow-[0_0_15px_rgba(var(--color-primary-500-rgb),0.2)] mb-8">
                <Globe className="w-8 h-8 text-primary-500 dark:text-primary-500" />
              </div>
              <div className="">
                <h3 className="text-xl tracking-widest mb-2 uppercase font-jakarta font-medium">
                  Cross-Grid Linkage
                </h3>
                <p className="text-xs font-mono uppercase text-slate-500 dark:text-gray-300 font-geist">
                  Sync archives across sector boundaries.
                </p>
              </div>
            </div>
          </GlowCard>
        </Reveal>

        {/* Card 4 */}
        <Reveal delay={0.4} className="md:col-span-12 lg:col-span-5 h-full">
          <GlowCard className="p-8 h-full min-h-[350px] bg-white dark:bg-[#0A0A0B] shadow-lg dark:shadow-[0_0_30px_rgba(0,0,0,0.8),inset_0_0_20px_rgba(var(--color-primary-500-rgb),0.05)] border border-slate-200 dark:border-primary-500/20 transition-colors overflow-hidden">
            <div className="absolute inset-0 pointer-events-none opacity-[0.03] dark:opacity-[0.03]" style={{ backgroundImage: "repeating-linear-gradient(-45deg, transparent, transparent 10px, currentColor 10px, currentColor 11px)" }}></div>
            <div className="relative z-10 w-full md:w-2/3 flex flex-col justify-center h-full">
              <h3 className="text-xl tracking-widest mb-2 uppercase font-jakarta font-medium">
                24/7 Command Support
              </h3>
              <p className="text-xs font-mono uppercase text-slate-500 dark:text-gray-300 font-geist">
                Direct channel to central intelligence.
              </p>
            </div>

            <div className="absolute -right-10 top-1/2 -translate-y-1/2 w-64 h-64 border border-primary-300 dark:border-primary-500/20 rounded-full flex items-center justify-center pointer-events-none">
              <div className="w-48 h-48 border border-dashed border-primary-400/50 dark:border-primary-500/30 rounded-full flex items-center justify-center rotate-45">
                <div className="w-32 h-32 border border-primary-300 dark:border-primary-500/20 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-primary-600 dark:bg-primary-600 rounded-sm shadow-[0_0_10px_#4f46e5]"></div>
                </div>
              </div>
            </div>
          </GlowCard>
        </Reveal>
      </div>
    </section>
  );
}
