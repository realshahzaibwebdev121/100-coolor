import React from 'react';
import { Menu } from 'lucide-react';
import { useState } from 'react';
import { Reveal } from './ui/Reveal';

export function CTA() {
  const [code, setCode] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(code) {
      // Simulate action
      console.log(`Executing code: ${code}`);
      setCode('');
      // In a real app we might show a toast here
    }
  };

  return (
    <section className="py-32 relative text-center overflow-hidden border-t border-primary-200 dark:border-primary-500/10">
      <div className="max-w-3xl mx-auto px-6 relative z-10">
        <Reveal>
          <h2 className="text-3xl md:text-5xl uppercase tracking-widest mb-16 font-jakarta font-medium">
            Access Mainframe
          </h2>
        </Reveal>

        <div className="relative w-full h-[200px] mb-12 flex justify-center items-center pointer-events-none">
          <div className="absolute w-[80%] h-px bg-primary-300 dark:bg-primary-500/20"></div>

          <div className="absolute left-[15%] w-10 h-10 border border-primary-300 dark:border-primary-500/30 bg-slate-50 dark:bg-[#141416] flex items-center justify-center transition-colors">
            <div className="w-3 h-3 bg-primary-600 dark:bg-primary-600/80 rounded-sm"></div>
          </div>

          <div className="relative w-24 h-24 border-[3px] border-primary-500 dark:border-primary-500 z-10 flex items-center justify-center bg-white dark:bg-[#0A0A0B] shadow-lg dark:shadow-[0_0_30px_rgba(var(--color-primary-500-rgb),0.3)] transition-colors">
            <div className="w-8 h-8 bg-primary-400 dark:bg-primary-500 rounded-sm rotate-45"></div>
          </div>

          <div className="absolute right-[15%] w-10 h-10 border border-primary-300 dark:border-primary-500/30 bg-slate-50 dark:bg-[#141416] flex items-center justify-center transition-colors">
            <Menu className="w-4 h-4 text-primary-500 dark:text-primary-500" />
          </div>
        </div>

        {/* Input group */}
        <Reveal delay={0.2} className="w-full max-w-md mx-auto relative mb-6">
          <form onSubmit={handleSubmit} className="rounded-sm flex items-center bg-slate-50 dark:bg-[#141416] border border-primary-300 dark:border-primary-500/40 p-1 pl-4 focus-within:border-primary-500 dark:focus-within:border-primary-500 transition-colors shadow-inner dark:shadow-[inset_0_0_10px_rgba(0,0,0,0.8)]">
            <input 
              type="text" 
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="ENTER COM_CODE..." 
              className="bg-transparent border-none outline-none flex-1 text-xs font-mono text-primary-600 dark:text-primary-500 placeholder-slate-400 dark:placeholder-[#9ca3af] uppercase tracking-widest w-full" 
            />
            <button type="submit" className="bg-slate-200 dark:bg-[#0A0A0B] border border-primary-400 dark:border-primary-500 text-primary-600 dark:text-primary-500 px-6 py-3 text-[10px] font-mono tracking-widest uppercase hover:bg-primary-100 dark:hover:bg-primary-900/50 transition-colors font-geist ml-2 whitespace-nowrap focus:outline-none">
              Execute
            </button>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
