import { Camera, Hash } from 'lucide-react';

export function Footer() {
  return (
    <footer className="relative border-t border-primary-200 dark:border-primary-500/10 pt-20 pb-10 overflow-hidden bg-slate-50 dark:bg-[#0A0A0B] transition-colors duration-500">
      <div className="absolute bottom-[-5%] left-1/2 -translate-x-1/2 text-[20vw] tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-slate-200 to-transparent dark:from-primary-500/[0.05] dark:to-transparent pointer-events-none select-none leading-none w-full text-center uppercase font-jakarta font-medium transition-all">
        nexus
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
          <div className="md:col-span-2">
            <h3 className="text-sm font-mono uppercase font-semibold tracking-widest text-slate-900 dark:text-white mb-4 font-geist">
              Prime Directive Protocol
            </h3>
            <p className="text-xs font-mono uppercase tracking-widest max-w-sm mb-8 leading-relaxed text-slate-500 dark:text-gray-300 font-geist">
              Strategic covert data architecture.
            </p>
            <div className="flex gap-4">
              <button aria-label="Social Link" className="w-10 h-10 border border-primary-300 dark:border-primary-500/30 bg-white dark:bg-[#141416] flex items-center justify-center hover:border-primary-500 dark:hover:border-primary-500 transition-colors hover:text-primary-600 dark:hover:text-primary-500 text-slate-400 dark:text-gray-300">
                <Hash className="w-4 h-4" />
              </button>
              <button aria-label="Social Link" className="w-10 h-10 border border-primary-300 dark:border-primary-500/30 bg-white dark:bg-[#141416] flex items-center justify-center hover:border-primary-500 dark:hover:border-primary-500 transition-colors hover:text-primary-600 dark:hover:text-primary-500 text-slate-400 dark:text-gray-300">
                <Camera className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div>
            <ul className="space-y-4 font-mono text-xs uppercase tracking-widest">
              <li>
                <a href="#features" className="text-slate-500 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-500 transition-colors font-geist">
                  Features
                </a>
              </li>
              <li>
                <a href="#dev" className="text-primary-600 dark:text-primary-500 font-medium border-l-[3px] border-primary-500 dark:border-primary-500 pl-2 font-geist">
                  Dev_Core
                </a>
              </li>
              <li>
                <a href="#platform" className="text-slate-500 dark:text-gray-300 hover:text-primary-500 dark:hover:text-primary-500 transition-colors font-geist">
                  Platform
                </a>
              </li>
            </ul>
          </div>

          <div>
            <ul className="space-y-4 font-mono text-xs uppercase tracking-widest">
              <li>
                <a href="#security" className="text-slate-900 dark:text-white font-medium hover:text-primary-500 dark:hover:text-primary-500 font-geist">
                  Security
                </a>
              </li>
              <li>
                <a href="#support" className="text-slate-900 dark:text-white font-medium hover:text-primary-500 dark:hover:text-primary-500 font-geist">
                  Support
                </a>
              </li>
              <li>
                <a href="#comms" className="text-slate-900 dark:text-white font-medium hover:text-primary-500 dark:hover:text-primary-500 font-geist">
                  Comms
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-8 border-t border-primary-200 dark:border-primary-500/10 text-[10px] font-mono uppercase tracking-widest text-slate-500 dark:text-gray-300">
          <p className="font-geist">SYS.DATE: {new Date().getFullYear()} // NEUROCORP</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#privacy" className="hover:text-primary-500 dark:hover:text-primary-500 transition-colors font-geist">
              Privacy_Log
            </a>
            <a href="#terms" className="hover:text-primary-500 dark:hover:text-primary-500 transition-colors font-geist">
              Terms_Def
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
