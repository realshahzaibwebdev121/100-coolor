import { useEffect, useRef } from 'react';
import { motion } from 'motion/react';

export function Backgrounds() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext('webgl');
    if (!gl) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      gl.viewport(0, 0, canvas.width, canvas.height);
    };
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const vertexShaderSource = `
      attribute vec2 position;
      void main() {
          gl_Position = vec4(position, 0.0, 1.0);
      }
    `;

    const fragmentShaderSource = `
      precision highp float;
      uniform vec2 u_resolution;
      uniform float u_time;

      float random(vec2 st) {
          return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
      }

      float noise(vec2 st) {
          vec2 i = floor(st);
          vec2 f = fract(st);
          float a = random(i);
          float b = random(i + vec2(1.0, 0.0));
          float c = random(i + vec2(0.0, 1.0));
          float d = random(i + vec2(1.0, 1.0));
          vec2 u = f * f * (3.0 - 2.0 * f);
          return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
      }

      float fbm(vec2 st) {
          float value = 0.0;
          float amplitude = 0.5;
          for (int i = 0; i < 5; i++) {
              value += amplitude * noise(st);
              st *= 2.0;
              amplitude *= 0.5;
          }
          return value;
      }

      void main() {
          vec2 uv = gl_FragCoord.xy / u_resolution.xy;
          vec2 p = uv * 2.0 - 1.0;
          p.x *= u_resolution.x / u_resolution.y;

          float beamX = -0.1;
          float dist = abs(p.x - beamX);
          float core = 0.001 / dist;
          core = smoothstep(0.0, 1.0, core);
          float glow = 0.02 / (dist + 0.05);

          vec2 smokeUV = vec2(p.x, p.y - u_time * 0.1);
          float smokeNoise = fbm(smokeUV * 3.0 + vec2(u_time * 0.05, 0.0));
          float smokeScatter = smoothstep(0.8, 0.0, dist);
          float smoke = smokeNoise * smokeScatter * 0.4;
          float pulse = sin(u_time * 2.0) * 0.1 + 0.9;

          vec3 beamColor = vec3(0.388, 0.4, 0.945); // primary-500
          vec3 smokeColor = vec3(0.658, 0.333, 0.968); // secondary-500
          vec3 coreColor = vec3(1.0, 1.0, 1.0);

          vec3 finalColor = core * coreColor + glow * beamColor * pulse + smoke * smokeColor;
          float edge = smoothstep(1.0, 0.4, abs(p.x)) * smoothstep(1.0, 0.2, abs(p.y));

          gl_FragColor = vec4(finalColor * edge, 1.0);
      }
    `;

    function compileShader(gl: WebGLRenderingContext, source: string, type: number) {
      const shader = gl.createShader(type);
      if(!shader) return null;
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      return shader;
    }

    const vertexShader = compileShader(gl, vertexShaderSource, gl.VERTEX_SHADER);
    const fragmentShader = compileShader(gl, fragmentShaderSource, gl.FRAGMENT_SHADER);
    if(!vertexShader || !fragmentShader) return;

    const program = gl.createProgram();
    if(!program) return;
    
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);

    const positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
      -1.0, -1.0,  1.0, -1.0, -1.0,  1.0,
      -1.0,  1.0,  1.0, -1.0,  1.0,  1.0
    ]), gl.STATIC_DRAW);

    const positionLocation = gl.getAttribLocation(program, 'position');
    gl.enableVertexAttribArray(positionLocation);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.useProgram(program);

    const timeLocation = gl.getUniformLocation(program, 'u_time');
    const resolutionLocation = gl.getUniformLocation(program, 'u_resolution');

    let startTime = performance.now();
    let animationId: number;

    function render() {
      const currentTime = performance.now();
      gl!.uniform1f(timeLocation, (currentTime - startTime) / 1000);
      gl!.uniform2f(resolutionLocation, canvas!.width, canvas!.height);
      gl!.drawArrays(gl!.TRIANGLES, 0, 6);
      animationId = requestAnimationFrame(render);
    }
    render();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <>
      <canvas ref={canvasRef} className="fixed inset-0 z-0 pointer-events-none w-full h-full opacity-0 dark:opacity-60 transition-opacity duration-500" />

      {/* SVG Noodles */}
      <svg className="fixed inset-0 w-full h-full pointer-events-none z-[1] opacity-20 dark:opacity-70 transition-opacity duration-500" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
            <filter id="noodle-glow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="0.15" result="blur"></feGaussianBlur>
                <feComposite in="SourceGraphic" in2="blur" operator="over"></feComposite>
            </filter>
        </defs>
        <path d="M 15,-10 C 15,30 85,70 85,110" fill="none" stroke="rgba(var(--color-primary-500-rgb),0.06)" strokeWidth="0.1"></path>
        <path d="M 15,-10 C 15,30 85,70 85,110" fill="none" stroke="#a855f7" strokeWidth="0.2" filter="url(#noodle-glow)" strokeDasharray="10 150">
            <animate attributeName="stroke-dashoffset" from="150" to="0" dur="6s" repeatCount="indefinite"></animate>
        </path>
        <path d="M 85,-10 C 85,40 20,60 20,110" fill="none" stroke="rgba(var(--color-primary-500-rgb),0.06)" strokeWidth="0.1"></path>
        <path d="M 85,-10 C 85,40 20,60 20,110" fill="none" stroke="#6366f1" strokeWidth="0.2" filter="url(#noodle-glow)" strokeDasharray="15 150">
            <animate attributeName="stroke-dashoffset" from="150" to="0" dur="8.5s" repeatCount="indefinite"></animate>
        </path>
        <path d="M 50,-10 C 65,30 35,60 50,110" fill="none" stroke="rgba(var(--color-primary-500-rgb),0.06)" strokeWidth="0.1"></path>
        <path d="M 50,-10 C 65,30 35,60 50,110" fill="none" stroke="#4f46e5" strokeWidth="0.15" filter="url(#noodle-glow)" strokeDasharray="5 100">
            <animate attributeName="stroke-dashoffset" from="100" to="0" dur="4.2s" repeatCount="indefinite"></animate>
        </path>
      </svg>

      <div className="fixed inset-0 z-[1] pointer-events-none bg-cover bg-center mix-blend-luminosity opacity-5 dark:opacity-10 blur-sm transition-opacity duration-500" style={{ backgroundImage: "url('https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/4b853ee7-0035-47f0-a177-608832b1214c_3840w.webp')" }}></div>
      <div className="fixed inset-0 z-[1] pointer-events-none opacity-5 dark:opacity-20 mix-blend-overlay transition-opacity duration-500" style={{ backgroundImage: "url('data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.8%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E')" }}></div>
      <div className="fixed inset-0 z-[1] pointer-events-none mix-blend-overlay opacity-10 dark:opacity-30 transition-opacity duration-500" style={{ backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(var(--color-primary-500-rgb), 0.1) 2px, rgba(var(--color-primary-500-rgb), 0.1) 4px)", backgroundSize: "100% 4px" }}></div>
      <div className="fixed inset-0 z-[1] pointer-events-none opacity-0 dark:opacity-100 transition-opacity duration-500" style={{ background: "radial-gradient(circle at center, transparent 0%, #0A0A0B 90%)" }}></div>

      {/* Boot sequence animated frames */}
      <motion.div initial={{ x: '-100%', y: '100%' }} animate={{ x: 0, y: 0 }} transition={{ duration: 1.5, ease: 'easeOut', delay: 0.2 }} className="fixed bottom-0 left-0 w-3/4 h-[75vh] bg-primary-400 dark:bg-secondary-500 z-[1] opacity-5 dark:opacity-10 pointer-events-none" style={{ clipPath: "polygon(0 100%, 0 20%, 80% 100%)" }}></motion.div>
      <motion.div initial={{ x: '-100%', y: '100%' }} animate={{ x: 0, y: 0 }} transition={{ duration: 1.5, ease: 'easeOut', delay: 0 }} className="fixed bottom-0 left-0 w-2/3 h-[66vh] bg-primary-500 dark:bg-primary-600 z-[1] opacity-5 dark:opacity-15 pointer-events-none" style={{ clipPath: "polygon(0 100%, 0 40%, 60% 100%)" }}></motion.div>
      <motion.div initial={{ x: '-100%' }} animate={{ x: 0 }} transition={{ duration: 1.2, ease: 'easeOut' }} className="fixed top-0 left-0 w-64 h-full bg-primary-400 dark:bg-secondary-500 z-[1] opacity-0 dark:opacity-5 pointer-events-none" style={{ clipPath: "polygon(0 0, 100% 0, 40% 100%, 0 100%)" }}></motion.div>
    </>
  );
}
