import { ArrowRight, Rss, Shield, Zap } from 'lucide-react';
import { Reveal } from './ui/Reveal';

export function Keycard() {
  return (
    <section className="max-w-7xl mx-auto px-6 py-16">
      <div className="bg-white dark:bg-[#0A0A0B] p-8 md:p-16 rounded-md flex flex-col lg:flex-row items-center gap-16 relative overflow-hidden transition-colors duration-500 shadow-xl dark:shadow-[inset_0_0_30px_rgba(var(--color-primary-500-rgb),0.05)] border border-slate-200 dark:border-primary-500/20">
        <div className="absolute inset-0 pointer-events-none opacity-[0.03]" style={{ backgroundImage: "repeating-linear-gradient(-45deg, transparent, transparent 10px, currentColor 10px, currentColor 11px)" }}></div>

        <Reveal delay={0.1} className="w-full lg:w-1/2 relative z-10 border-l-[6px] border-primary-500 dark:border-primary-500 pl-8">
          <div className="text-xs font-mono text-primary-600 dark:text-primary-500 uppercase tracking-widest mb-6 font-geist">
            Clearance_Badge
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl uppercase tracking-widest mb-12 max-w-md leading-tight drop-shadow-sm dark:drop-shadow-[0_0_10px_rgba(255,255,255,0.2)] font-jakarta font-medium text-slate-900 dark:text-white">
            Level 5 Identification Badge
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
            <div>
              <div className="w-8 h-8 mb-4 border border-primary-400/50 dark:border-primary-500/40 flex items-center justify-center text-primary-600 dark:text-primary-500">
                <Shield className="w-4 h-4" />
              </div>
              <p className="text-xs font-mono uppercase leading-relaxed text-slate-600 dark:text-gray-300 font-geist">
                Keep under strict surveillance until authorized.
              </p>
            </div>
            <div>
              <div className="w-8 h-8 mb-4 border border-primary-400/50 dark:border-primary-500/40 flex items-center justify-center text-primary-600 dark:text-primary-500">
                <Zap className="w-4 h-4" />
              </div>
              <p className="text-xs font-mono uppercase leading-relaxed text-slate-600 dark:text-gray-300 font-geist">
                Quantum-speed tunneling via Mainline networks.
              </p>
            </div>
          </div>

          <button className="group relative flex items-center justify-center px-8 py-3 w-max cursor-pointer overflow-hidden bg-gray-300 dark:bg-[#1A2A3A]/40 border border-slate-200 dark:border-white/5 backdrop-blur-sm shadow-sm dark:shadow-[inset_0_2px_10px_rgba(0,0,0,0.5)]">
            <div className="absolute left-0 top-0 bottom-0 w-[4px] bg-primary-500 dark:bg-primary-500 transition-all group-hover:w-[8px] group-hover:bg-slate-900 dark:group-hover:bg-white shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.5)] dark:shadow-[0_0_10px_rgba(var(--color-primary-500-rgb),0.5)]"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-primary-400/0 via-primary-400/10 to-primary-400/0 dark:from-primary-500/0 dark:via-primary-500/10 dark:to-primary-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <span className="relative z-10 font-mono text-xs tracking-widest uppercase flex items-center gap-2 text-slate-900 dark:text-white group-hover:drop-shadow-[0_0_8px_rgba(0,0,0,0.3)] dark:group-hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] font-geist">
              Issue Badge
              <ArrowRight className="w-4 h-4" />
            </span>
          </button>
        </Reveal>

        {/* Right Visual (Keycard) */}
        <Reveal delay={0.3} className="w-full lg:w-1/2 flex justify-center lg:justify-end relative z-10">
          <div className="w-[300px] h-[480px] bg-slate-900 dark:bg-[#0A0A0B] border-2 border-primary-500/50 dark:border-primary-500/50 p-8 relative overflow-hidden shadow-2xl dark:shadow-[0_0_30px_rgba(var(--color-primary-500-rgb),0.2)] transform transition-transform hover:scale-105 duration-500 text-white">
            <div className="flex justify-between items-start relative z-10 border-b border-primary-500/30 dark:border-primary-500/30 pb-4">
              <span className="text-primary-400 dark:text-primary-500 text-[10px] font-mono uppercase tracking-widest font-geist">
                Auth_ID<br />0x774-B
              </span>
              <Rss className="w-5 h-5 text-primary-400 dark:text-primary-500 rotate-90" />
            </div>

            <div className="mt-12 relative z-10">
              <h3 className="text-4xl tracking-widest uppercase font-jakarta font-medium text-white">nexus</h3>
            </div>

            <div className="mt-8 border-l-[4px] border-primary-600 dark:border-primary-600 pl-4 relative z-10">
              <p className="text-[10px] font-mono uppercase tracking-widest text-slate-300 dark:text-gray-300 font-geist">
                Clearance Level
              </p>
              <p className="text-xs font-mono text-primary-500 dark:text-primary-600 uppercase tracking-widest mt-1 font-geist">
                Alpha_1
              </p>
            </div>

            {/* Barcode Array */}
            <div className="absolute bottom-24 left-8 right-8 flex gap-[2px] h-8 opacity-60">
              {[1, 2, 0.5, 3, 1, 2, 0.5, 1, 4, 1, 2, 0.5].map((w, i) => (
                <div key={i} className="bg-primary-400 dark:bg-primary-500" style={{ width: `${w * 4}px` }}></div>
              ))}
            </div>

            <div className="absolute bottom-8 left-8 right-8 flex justify-between items-end relative z-10 mt-auto pt-32">
              <span className="text-primary-400 dark:text-primary-500 font-mono tracking-widest text-[10px] uppercase font-geist">
                K. Vance
              </span>
              <div className="w-4 h-4 border border-primary-400 dark:border-primary-500 bg-primary-900/50 dark:bg-primary-900/50"></div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
